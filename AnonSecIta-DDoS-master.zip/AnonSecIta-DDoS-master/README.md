![anonsecitalogo](https://github.com/xPloits3c/AnonSecIta-DDoS/assets/153435050/75480311-8587-4ca2-9ebb-b79ef697e6d6)
[![release v1.0 ](https://img.shields.io/badge/release-v1.1-green.svg?style=flat-square)](https://github.com/xPloits3c/AnonSecIta-DDoS/releases/)
[![Github Stars](https://img.shields.io/github/stars/xPloits3c/AnonSecIta-DDoS.svg?style=social&label=Stars)](https://github.com/xPloits3c/AnonSecIta-DDoS/)
[![Follow on Twitter](https://img.shields.io/twitter/follow/AnonSecIta.svg?style=social&label=Follow)](https://twitter.com/AnonSecIta/)
# DDoS Tool (L7 L4)

- Programming Language - Python 3
- Proxy List Updated

# Don't Attack websites without the owners consent.
- ⚠️ The use of this tool to attack targets without prior mutual consent is illegal.
- ⚠️ It is the responsibility of the end user to comply with all applicable local, state, and federal laws.
- 💢 The developers assume no responsibility and are not responsible for any abuse or damage caused by this program.

# DOS/DDOS attacks are the first officially recognized class of attacks and were first used in the mid-1970s.
![DDoSAttack-3346572643](https://github.com/xPloits3c/AnonSecIta-DDoS/assets/153435050/43ea421a-fef1-4a21-ace5-e29652688979)

# 💣 Layer7 L7 DDoS (for Layer 7)
- This type of attack directly targets applications.
- The goal is not to "shut down" the network, but the service itself, flooding it with requests.
- These tools target layer 7 of the OSI model, where Internet requests such as HTTP are established.
- By using an HTTP flood type of attack to overwhelm a target with HTTP GET and POST requests.
- An attacker can launch attack traffic that is difficult to distinguish from harmless requests from regular visitors.
 
# 🧨 Layer4 L4 DDoS (UDP-RAW-TCP-SYN)
- This category includes all those attacks that, for example, use malformed packets (tcp, syn and ack).
- Further down the protocol stack, these tools use protocols such as UDP to send large volumes of traffic to a designated server, such as during a UDP flood event.
- While often ineffective individually, these attacks typically take the form of DDoS attacks where the effect is enhanced by additional attacking machines.

![anonsecitaddos l7l4](https://github.com/xPloits3c/AnonSecIta-DDoS/assets/153435050/f86b3e0e-f533-451c-adb0-484537d8c2d0)
![dattackproxy](https://github.com/xPloits3c/AnonSecIta-DDoS/assets/153435050/085d6db6-1434-4f01-87de-069079c151ab)

# How to use

- git clone https://github.com/xPloits3c/AnonSecIta-DDoS.git
- cd AnonSecIta-DDoS
- python3 anonsecita-ddos.py

# If u Like the project, leave a star on the repository!
![github_logo-602056228](https://github.com/xPloits3c/AnonSecIta-DDoS/assets/153435050/a39d6f76-88ff-4d55-ab63-e38a08e0d609)

