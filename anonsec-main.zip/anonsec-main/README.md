![anonsecmain](https://user-images.githubusercontent.com/78624983/201806206-59b4c085-9690-4f2c-92fc-56ff79b2227d.PNG)




⚠️ L'uso di anonsec per attaccare obiettivi senza previo consenso reciproco è illegale.

⚠️ È responsabilità dell'utente finale rispettare tutte le leggi locali, statali e federali applicabili.

💢 Gli sviluppatori non si assumono alcuna responsabilità e non sono responsabili per eventuali abusi o danni causati da questo programma.

➢ Telegram AnonSecIta: https://t.me/AnonSecITA
          

![requestsentanonsec](https://user-images.githubusercontent.com/78624983/201806240-591390e2-0958-4d5c-85d3-2ae21b19c1e3.PNG)

➢ Come Usare anonsec 💻 

1) git clone https://github.com/anovni/anonsec.git

2) cd anonsec

3) python3 anonsec.py

4) 0

5) https://IlTuoSitoWeb(.)it

6) y

7) 1

8) 800

9) 100

10) Enter



