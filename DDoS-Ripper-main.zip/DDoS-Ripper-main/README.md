# DDoS-Ripper

# What is a DDoS Attack?
A Distributable Denied-of-Service (DDOS) attack server that cuts off targets or surrounding infrastructure in a flood of Internet traffic

DDoS attacks achieve effectiveness using multiple compromised computer systems as a source of attack traffic. Search engines may include computers and other network resources such as IoT devices.
From a higher level, the DDOS attack is like an unexpected traffic jam stuck on a highway, preventing regular traffic from reaching its destination.

## NOTE (Please, make sure you have installed python 3 )

![dddd](https://user-images.githubusercontent.com/49250151/96265488-57e53d00-0f7a-11eb-8936-ce2e9a2c42cd.PNG)

## For Termux
To use the DRipper type the following commands in Termux:

`pkg install git -y`

`pkg install python -y`

`pkg install python3 -y`

`git clone https://github.com/palahsu/DDoS-Ripper.git`

`cd DDoS-Ripper`
`$ ls`

`$ python3 DRipper.py` 

## USGAE
`python3 DRipper.py -s [ip Address] -t 135`

`example: python3 DRipper.py -s 0.00.00.00 -t 135`

## For Debian-based GNU/Linux distributions
To use the application, type in the following commands in GNU/Linux terminal.

`sudo apt install git`
`git clone https://github.com/palahsu/DDoS-Ripper.git`
`cd DDoS-Ripper`
`$ ls`
`$ python3 DRipper.py` OR `python2 DRipper.py`

## For Windows

`git clone https://github.com/palahsu/DDoS-Ripper`

`cd DDoS-Ripper`
` ls`

`python3 DRipper.py` OR `python DRipper.py`

`python3 DRipper.py -s [ip Address] -t 135`

`example: python3 DRipper.py -s 0.00.00.00 -t 135`

## For MacOS

Install Brew and Install dependencies (python 3)

# Note:
If you find any problems than please write on issue github and to our Telegram Group. Don't use for revenge! Make sure your anonymity!
It's made for just testing purpose.
We are not responsible for any abuse or damage caused by this program. Only for Educational Purpose.
Thanks.
 
## Requirments ▶

●🖥Linux OS( Kali 🐉 Ubuntu )

●📱Termux >

●🖥Windows

●🖥MAC

# Modified by @palahsu

For any kind of help, support, payment, suggetion and request ask me on Telegram:

<a href="https://t.me/CyberClans"><img src="https://img.shields.io/badge/Telegram-Group%20Telegram%20Join-blue.svg?logo=telegram"></a>

Or Facebook <a href="https://www.facebook.com/aduri.knox01/"><img src="https://img.shields.io/badge/Facebook-Follow%20on%20Facebook-blue.svg?logo=facebook"></a>

## Follow on:
<p align="left">
<a href="https://github.com/palahsu"><img src="https://img.shields.io/badge/GitHub-Follow%20on%20GitHub-inactive.svg?logo=github"></a>
</p><p align="left">
<a href="https://www.facebook.com/aduri.knox01/"><img src="https://img.shields.io/badge/Facebook-Follow%20on%20Facebook-blue.svg?logo=facebook"></a>
</p><p align="left">
<a href="https://t.me/AD0000000"><img src="https://img.shields.io/badge/Telegram-Contact%20Telegram%20Profile-blue.svg?logo=telegram"></a>
</p><p align="left"> 
 
