import requests
import sys
import json
from colorama import Fore, Back, Style
import os

def welcome():
    f = open("header.txt", "r")
    print (f.read())

