import os
import sys
def verify():
    os.system(' cd modules && sh nmap.sh ')

