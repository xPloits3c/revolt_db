import os
import sys
from colorama import Fore, Back, Style
import requests

def help(syA1):
        print(Fore.WHITE)
        f = open("help.txt")
        print (f.read())


