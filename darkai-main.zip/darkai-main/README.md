# ➢ darkai 100% IN ITALIANO

![main menù](https://user-images.githubusercontent.com/78624983/185513505-cb5c59bd-20b4-4942-8014-b135c68b0287.jpg)



# ➢ Benvenuto! 💻

➢ Questo tool contiene oltre 300 tool per pentesting e hacking, ed è esclusivamente SOLO PER SCOPI DIDATTICI. :D

# ➢ E' PERICOLOSO AVERE RAGIONE QUANDO IL GOVERNO HA TORTO!

➢ Questa è una raccolta di tool, non organizzati, molti di loro hanno depedenze obsolete.

➢ Il mio obiettivo è quello di metterli insieme collettivamente in lingua italiana modo che siano compilabili e aiutare le persone interessate alla ricerca e imparare da questi campioni.

# ⚠️ COME USARE DARKAI

![darkai menu tools](https://user-images.githubusercontent.com/78624983/184938775-fa728293-73e0-42dd-801f-bc78274ea897.jpg)

1) ➢ git clone https://github.com/anovni/darkai.git
2) ➢ cd darkai
3) ➢ bash darkai.sh
4) ➢ Digita il numero del tool che vorresti installare.
5) ➢ Buon divertimento!

#  NOI SIAMO ANONYMOUS
