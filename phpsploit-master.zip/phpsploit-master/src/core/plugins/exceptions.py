"""Plugin-related exceptions
"""


class BadPlugin(Exception):
    """Invalid plugin exception"""
