# Phpsploit Functional Tests Suite

# Usage:
    ./RUN.sh --help

# About:
    * The test launcher recursively runs all tests in subdirectories
    * Only executable scripts are run by test launcher (chmod +x).
