MISC TESTS TO PERFORM
=====================


# Proxy feature:
    - Test http/https/socks4/socks5 proxy tunneling.
    - Test proxy tunnelling, with proxy gathered from `http_proxy` and
      `https_proxy` environment variables.

# Settings
    - Test `%%DEFAULT_VALUE%%` magic value for each setting.

# Core commands:
    - All options of each available core command must be tested.
    - Test expected return values

# Plugins:
    - All options of each available plugin must be tested.
    - Test expected return values

# Tunnel:
    - Test
