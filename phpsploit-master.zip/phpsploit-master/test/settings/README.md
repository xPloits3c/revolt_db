# Functional Tests: settings

Test phpsploit `Configuration Settings`.
Settings can be listed with `phpsploit -e set`.
