![](https://img.shields.io/badge/python-v3.7-blue)

Mass deface's 1500 website on one go


This shitty tool here defaces all the website on the list

this is an old vuln

I dont have time to explain this shitty tool figure it out yourself . Dont be a script kiddie

Iam too lazy to update target list


this tool is for educational purposes only dont missuse it iam not responsible!





